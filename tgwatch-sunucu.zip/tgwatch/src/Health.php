<?php
declare(strict_types=1);

namespace TgWatch;

/** Kurulum ve çalışma kontrolleri (tools/check.php ve web paneldeki Sağlık sayfası). */
final class Health
{
    public const OK = 'ok';
    public const WARN = 'warn';
    public const FAIL = 'fail';

    /** @return list<array{0:string,1:string,2:string}> [başlık, durum, ayrıntı] */
    public static function local(array $c): array
    {
        $r = [];
        $r[] = ['PHP sürümü', version_compare(PHP_VERSION, '8.1.0', '>=') ? self::OK : self::FAIL, PHP_VERSION . ' (8.1+ gerekli)'];
        foreach (['curl', 'mbstring', 'dom', 'pdo_sqlite', 'json'] as $ext) {
            $r[] = ["Eklenti: $ext", extension_loaded($ext) ? self::OK : self::FAIL, extension_loaded($ext) ? 'yüklü' : 'YOK — PHP seçicisinden açın'];
        }
        $r[] = ['config.php', !empty($c['_has_config_file']) ? self::OK : self::FAIL, (!empty($c['_has_config_file']) ? 'okunan dosya: ' : 'yok — şu adla boş bir dosya oluşturup içine <?php return []; yazın: ') . TGWATCH_ROOT . '/config.php'];
        if (!empty($c['_unknown_keys'])) {
            $r[] = ['config.php anahtarları', self::FAIL, 'tanınmayan: ' . implode(', ', $c['_unknown_keys'])
                . " — değerler sağ tarafa yazılmalı, ör. 'bot_token' => '123:AA...', 'owner_id' => 123"];
        }
        $tokOk = (new Telegram((string)$c['bot_token']))->configured();
        $r[] = ['bot_token', $tokOk ? self::OK : self::FAIL, Telegram::describeToken((string)$c['bot_token'])];
        $r[] = ['owner_id', (int)$c['owner_id'] > 0 ? self::OK : self::FAIL, (int)$c['owner_id'] > 0 ? 'ayarlı' : 'boş — bota /start yazın, gelen ID\'yi girin'];
        if (($c['login_required'] ?? true) === false) {
            $r[] = ['Panel girişi', self::FAIL, 'KAPALI (login_required => false): adresi bilen herkes paneli yönetebilir' . (trim((string)($c['allowed_ips'] ?? '')) !== '' ? ' — yalnızca şu IP\'ler: ' . $c['allowed_ips'] : ' — allowed_ips ile IP sınırı koyun')];
        } elseif (trim((string)($c['allowed_ips'] ?? '')) !== '') {
            $r[] = ['IP sınırı', self::OK, 'panel yalnızca şu adreslerden açılır: ' . $c['allowed_ips']];
        }
        $r[] = ['admin_password_hash', str_starts_with((string)$c['admin_password_hash'], '$') ? self::OK : self::FAIL, $c['admin_password_hash'] === '' ? 'boş — php tools/make_hash.php' : 'ayarlı'];
        if ($c['bot_mode'] === 'webhook') {
            $okUrl = str_starts_with((string)$c['webhook_url'], 'https://');
            $r[] = ['webhook_url', $okUrl ? self::OK : self::FAIL, $okUrl ? $c['webhook_url'] : 'boş — Ayarlar → Telegram botu → Webhook adresi: https://…/public/bot.php (ya da Bot modu: Polling)'];
            $r[] = ['webhook_secret', preg_match('/^[A-Za-z0-9_-]{16,256}$/', (string)$c['webhook_secret']) ? self::OK : self::FAIL, $c['webhook_secret'] === '' ? 'boş — Ayarlar → Telegram botu → Webhook anahtarı: "Yeni rastgele anahtar üret"i işaretle, kaydet' : 'ayarlı'];
        } else {
            $r[] = ['bot_mode', self::OK, 'polling (butonlar cron aralığında işlenir)'];
        }
        $r[] = ['cron_key', preg_match('/^[A-Za-z0-9_-]{16,256}$/', (string)$c['cron_key']) ? self::OK : self::WARN,
            $c['cron_key'] === '' ? 'boş — cron-job.org kullanacaksanız gerekli' : 'ayarlı'];
        $tfOn = ($c['login_2fa'] ?? null) !== false && App::db()->get('login_2fa', '0') === '1';
        $r[] = ['İki adımlı giriş', $tfOn ? self::OK : self::WARN, $tfOn ? 'açık (Telegram kodu)' : (($c['login_2fa'] ?? null) === false ? 'config.php ile kapalı' : 'kapalı — Uyarılar ve güvenlik sayfasından açılabilir')];
        $hasMail = filter_var((string)($c['alert_email'] ?? ''), FILTER_VALIDATE_EMAIL) !== false;
        $r[] = ['İkinci uyarı yolu', ($hasMail || (string)($c['monitor_key'] ?? '') !== '') ? self::OK : self::WARN,
            ($hasMail || (string)($c['monitor_key'] ?? '') !== '') ? ($hasMail ? 'uyarı e-postası tanımlı' : 'dış izleme anahtarı tanımlı') : 'yok — Telegram bozulursa uyarı alamazsınız (Ayarlar → Telegram → Uyarı e-postası ya da Kanal okuma → İzleme anahtarı)'];
        $r[] = ['publisher', $c['publisher'] === 'manual' ? self::OK : self::WARN, $c['publisher'] === 'manual' ? 'manual (onaydan sonra panelde elle eklenir; API gelince otomatik)' : 'admin_api henüz desteklenmiyor'];
        try {
            $ai = new Ai(App::db(), $c);
            $r[] = ['Çeviri yöntemi', $ai->mode() !== 'bank' && !$ai->configured() ? self::WARN : self::OK,
                Ai::MODES[$ai->mode()] . ($ai->mode() !== 'bank' && !$ai->configured() ? ' — Claude API anahtarı yok, banka+kurallar kullanılıyor' : '')];
        } catch (\Throwable) {
        }

        $dir = (string)$c['data_dir'];
        $r[] = ['data_dir yazılabilir', is_dir($dir) && is_writable($dir) ? self::OK : self::FAIL, $dir];
        if (App::insideDocRoot(TGWATCH_ROOT)) {
            // Yalnızca var olan klasörlere bakılır (olmayan klasörün korunması gerekmez).
            $missing = array_filter(['', '/src', '/tools', '/tests', '/data', '/chrome-extension'], static fn($d) => is_dir(TGWATCH_ROOT . $d) && !is_file(TGWATCH_ROOT . $d . '/.htaccess'));
            $r[] = ['Web koruması', $missing ? self::FAIL : self::OK, $missing
                ? '.htaccess eksik: ' . implode(', ', array_map(static fn($d) => ($d ?: '/') , $missing)) . ' — zip\'teki gizli dosyalar (.htaccess) açılmamış olabilir'
                : 'tgwatch public_html içinde; .htaccess dosyaları yerinde, veritabanı adı rastgele'];
        }
        if (is_dir($dir) && App::insideDocRoot($dir) && !is_file($dir . '/.htaccess')) {
            $r[] = ['data_dir konumu', self::WARN, 'public_html içinde ve .htaccess yok (veritabanı adı rastgele olduğu için yine de tahmin edilemez)'];
        }
        if (is_file(TGWATCH_ROOT . '/config.php') && (fileperms(TGWATCH_ROOT . '/config.php') & 0o004)) {
            $r[] = ['config.php izinleri', self::WARN, 'herkes okuyabilir — 600 ya da 640 yapın'];
        }

        try {
            $db = App::db();
            $r[] = ['Veritabanı', self::OK, 'açıldı'];
            $last = (int)$db->get('cron_last_run', '0');
            $age = time() - $last;
            $r[] = ['Cron son çalışma', $last === 0 ? self::FAIL : ($age < 600 ? self::OK : self::WARN),
                $last === 0 ? 'hiç çalışmadı' : date('Y-m-d H:i:s', $last) . " ($age sn önce)"];
            $res = $db->getJson('cron_last_result');
            if (is_array($res)) {
                $r[] = ['Cron son sonuç', $res['errors'] ? self::WARN : self::OK, "{$res['errors']} hata, {$res['seconds']} sn"];
            }
            foreach ($db->all('SELECT * FROM channels ORDER BY username') as $ch) {
                $state = !$ch['enabled'] ? self::WARN : ($ch['last_error'] ? self::FAIL : ($ch['last_ok_at'] ? self::OK : self::WARN));
                $detail = !$ch['enabled'] ? 'kapalı' : ($ch['last_error'] ?: ($ch['last_ok_at'] ? 'son okuma ' . date('H:i:s', (int)$ch['last_ok_at']) : 'henüz okunmadı'));
                $r[] = ['Kanal @' . $ch['username'], $state, $detail];
            }
        } catch (\Throwable $e) {
            $r[] = ['Veritabanı', self::FAIL, $e->getMessage()];
        }
        return $r;
    }

    /** Ağ gerektiren kontroller (yavaş olabilir). */
    public static function network(array $c): array
    {
        $r = [];
        $t = Http::get('https://t.me/s/telegram', 15);
        $parsed = $t['error'] === '' ? ChannelReader::parse($t['body']) : null;
        $r[] = ['t.me erişimi', $t['error'] === '' && $t['status'] === 200 ? self::OK : self::FAIL,
            $t['error'] !== '' ? $t['error'] : 'HTTP ' . $t['status'] . ($parsed ? ', ' . count($parsed['posts']) . ' gönderi ayrıştırıldı' : '')];
        if ($parsed && $t['status'] === 200 && !$parsed['posts']) {
            $r[] = ['t.me/s ayrıştırma', self::FAIL, $parsed['error'] ?: 'gönderi bulunamadı'];
        }

        $tg = new Telegram((string)$c['bot_token']);
        if (!$tg->configured()) {
            $r[] = ['Bot API', self::FAIL, 'bot_token: ' . Telegram::describeToken((string)$c['bot_token'])];
            return $r;
        }
        try {
            $me = $tg->call('getMe', [], 15);
            $r[] = ['Bot API (getMe)', self::OK, '@' . ($me['username'] ?? '?')];
        } catch (\Throwable $e) {
            $r[] = ['Bot API (getMe)', self::FAIL, $e->getMessage()];
            return $r;
        }
        try {
            $wh = $tg->call('getWebhookInfo', [], 15);
            $url = (string)($wh['url'] ?? '');
            if ($c['bot_mode'] === 'webhook') {
                $state = $url === $c['webhook_url'] ? self::OK : self::FAIL;
                $detail = $url === '' ? 'kurulu değil — php tools/set_webhook.php' : ($url === $c['webhook_url'] ? 'kurulu' : "farklı adres: $url");
                if (!empty($wh['last_error_message'])) {
                    $state = self::WARN;
                    $detail .= ' · son hata: ' . $wh['last_error_message'] . ' (' . date('Y-m-d H:i', (int)($wh['last_error_date'] ?? 0)) . ')';
                }
                if (!empty($wh['pending_update_count'])) {
                    $detail .= ' · bekleyen: ' . $wh['pending_update_count'];
                }
                $r[] = ['Webhook', $state, $detail];
            } else {
                $r[] = ['Webhook', $url === '' ? self::OK : self::FAIL, $url === '' ? 'yok (polling için doğru)' : "kurulu ($url) — polling çalışmaz, tools/set_webhook.php --delete"];
            }
        } catch (\Throwable $e) {
            $r[] = ['Webhook', self::FAIL, $e->getMessage()];
        }
        $ai = new Ai(App::db(), $c);
        if ($ai->configured()) {
            $a = Http::request('GET', 'https://api.anthropic.com/v1/models/' . $ai->model(), ['x-api-key: ' . $ai->apiKey(), 'anthropic-version: ' . Ai::API_VERSION], null, 15);
            $r[] = ['Claude API', $a['status'] === 200 ? self::OK : self::FAIL, $a['error'] ?: ($a['status'] === 200 ? $ai->model() . ' erişilebilir' : 'HTTP ' . $a['status'] . ($a['status'] === 401 ? ' (anahtar geçersiz)' : ''))];
        }
        return $r;
    }
}
